# Common Tree for MT6781 Devices (4.19)
```
#
# Copyright (C) 2023 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#
```
